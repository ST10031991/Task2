/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package task;

import javax.swing.JOptionPane;
import javax.swing.JFrame;
 /**
 *
 * @author ochim
 */
public class Task {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        
  JFrame details = new JFrame();
Task task = new Task();

JOptionPane.showMessageDialog(null, "Welcome to KanBan");       
String option = JOptionPane.showInputDialog(details, "Choose one of the following: \n " +
"1. Add tasks \n" +
"2. Coming soon \n" +
"3. Quit \n");


int x;
 x = Integer.parseInt(option);
 
}   
{        
{
}
       
        
if ( x == 1)
      
{
String task1 = JOptionPane.showInputDialog(details, "Number of tasks:");

Integer.parseInt(task1);

String descri = JOptionPane.showInputDialog(null, "Task Description:");

}
{  
{       
}             
while (!task.checkTaskDescription(desc)) 
    
{
    
JOptionPane.showInputDialog(details, "Enter description");

} 
{
    
}
else if (x == 2)
        
{
}

        
{ 
        
}      
JOptionPane.showMessageDialog(details, "Coming Soon");
        
}

else if (x == 3)
        
{       
System.exit(0);
   
}
}
}
    
  
 